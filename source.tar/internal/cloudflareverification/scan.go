package cloudflareverification

import (
	"context"
	"encoding/hex"
	"github.com/aidotmarket/aim-data-gateway/internal/wire"
	core "github.com/aidotmarket/aim-data-gateway/verification"
	"sync"
	"time"
)

type Handler struct {
	Config Config
	Now    func() time.Time
}

func (h Handler) now() time.Time {
	if h.Now != nil {
		return h.Now().UTC()
	}
	return time.Now().UTC()
}

type collectedCommitments struct {
	Commitments
	Digests map[string]string
}

func (c *collectedCommitments) ObjectID(m core.Member) string {
	c.Digests[m.Identity] = hex.EncodeToString(m.SHA256[:])
	return c.Commitments.ObjectID(m)
}
func scanPolicy(j wire.ScanJob, c *collectedCommitments) core.Policy {
	p := core.Policy{
		CanonicalizationVersion:   "python-json-sort-compact-v1",
		RowCountAlgorithmVersion:  "exact-v1",
		DistinctAlgorithmVersion:  "hll-sha256-v1",
		HistogramVersion:          "fixed-buckets-v1",
		NumericBucketVersion:      "fixed-buckets-v1",
		MinimumAggregateOccupancy: 10,
		LengthBounds: []int{
			0,
			1,
			4,
			8,
			16,
			32,
			64,
			128,
			256,
		},
		NumericBoundaries: []float64{
			-1000,
			-100,
			-10,
			0,
			10,
			100,
			1000,
		},
		MaxMemoryBytes: core.MaxMemoryBytes,
		MaxRecordBytes: 16 << 20,
		MaxScalarBytes: 16 << 20,
		MaxColumns:     1000,
		MaxFactBytes:   32768,
		Deadline:       CF_VERIFY_DEADLINE_SECONDS * time.Second,
		Commitments:    c,
	}
	if censusJob(j) {
		p.ScanMode, p.BindingMethod = core.ContentCensusV1, "planned_read_commitment_v2"
		p.ContentReadBudgetBytes, p.ArchiveAllowanceBytes = censusR1BudgetBytes, censusR1ArchiveAllowanceBytes
		p.PlannedProcessedBytes = plannedBytes(j)
		p.ArchiveCaps = core.ArchiveCaps{UncompressedBytes: 256 << 20, Entries: 10000, CompressionRatio: 1000}
		p.PatternVersions = []string{"email_v1", "phone_e164_or_separated_v1", "credential_v1", "licence_families_v1", "simhash64_5shingle_v1"}
	}
	b, _ := hex.DecodeString(j.Text("deterministic_seed"))
	copy(p.Seed[:], b)
	return p
}
func (h Handler) scan(ctx context.Context, s *Secret, j wire.ScanJob, src *Source) ([]byte, error) {
	started := h.now()
	c := &collectedCommitments{Commitments: Commitments{Bucket: h.Config.Bucket, ManifestHash: j.Text("manifest_hash"), Key: s.Commitment}, Digests: map[string]string{}}
	// HEAD all members before fact inspection, after consent/audit acknowledgment.
	var e error
	if censusJob(j) {
		e = headMembers(ctx, src)
	} else {
		for _, m := range src.Members() {
			_, _, e = src.request(ctx, m.Identity)
			if e != nil {
				break
			}
		}
	}
	variant := j.Envelope.Variant
	var document map[string]any
	var digests []string
	if variant == "probe" {
		var result probeResult
		if e == nil {
			result, e = probe(ctx, src, scanPolicy(j, c))
		}
		class := "large"
		var total int64
		for _, m := range src.Members() {
			total += m.Size
		}
		if total < 10000000 {
			class = "small"
		} else if total < 100000000 {
			class = "medium"
		}
		if result.EstimatedMaxInputTokens == 0 {
			result.EstimatedMaxInputTokens = 8192
		}
		document = map[string]any{
			"probe_id":            j.Text("probe_id"),
			"spec_id":             j.Text("spec_id"),
			"spec_hash":           j.Envelope.SpecHash,
			"nonce_echo":          j.Text("nonce"),
			"install_key_id":      s.Receipt,
			"affected_file_ids":   []string{},
			"signature_algorithm": "Ed25519",
			"probe": map[string]any{
				"listing_id":         j.Text("listing_id"),
				"source_handle_id":   j.Text("source_handle_id"),
				"connector_type":     "r2_verifier",
				"connector_version":  "r2_verifier-v1",
				"owner_consent":      true,
				"source_reachable":   e == nil,
				"objects_discovered": len(src.Members()),
				"size_class":         class,
				"supported_capabilities": []string{
					"complete_traversal",
					"deterministic_object_order",
					"fixed_bucket_aggregates",
					"exact_or_declared_estimated_row_counts",
				},
				"estimated_max_input_tokens": result.EstimatedMaxInputTokens,
				"preview_requested":          j.Preview(),
			},
		}
		if censusJob(j) && result.CensusPreflight != nil {
			document["probe"].(map[string]any)["census_preflight"] = result.CensusPreflight
		}
		if e != nil {
			document["probe"].(map[string]any)["refusal_reason"] = errorCode(e)
		}
	} else {
		var f core.Facts
		if e == nil {
			f, e = core.Scan(ctx, src, scanPolicy(j, c))
		}
		if e == nil {
			e = ctx.Err()
		}
		if e != nil {
			variant = "terminal"
			document = terminal(j, errorCode(e), h.now())
		} else {
			document = report(j, f, started, h.now())
			digests = make([]string, 0, len(src.Members()))
			for _, m := range src.Members() {
				if censusJob(j) {
					break
				}
				digest := c.Digests[m.Identity]
				if !hex64.MatchString(digest) {
					return nil, ErrRefused
				}
				digests = append(digests, digest)
			}
		}
	}
	return encodeReport(s, j, variant, document, digests)
}
func errorCode(e error) string { return core.RefusalReason(e) }
func encodeReport(s *Secret, j wire.ScanJob, variant string, d map[string]any, digests []string) ([]byte, error) {
	if e := signReceipt(d, s.Private, variant); e != nil {
		return nil, e
	}
	raw, e := core.Canonical(d)
	if e != nil || len(raw) > wire.MaxScanDocument {
		return nil, ErrRefused
	}
	b := reportBody(j, variant, raw)
	if variant == "scan" && !censusJob(j) {
		if len(digests) == 0 || len(digests) > MaxMembers {
			return nil, ErrRefused
		}
		b["member_sha256s"] = digests
	}
	raw, e = core.Canonical(b)
	if e != nil || len(raw) > MaxReport {
		return nil, ErrRefused
	}
	return raw, nil
}

func headMembers(ctx context.Context, s *Source) error {
	members := s.Members()
	errs := make([]error, len(members))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for worker := 0; worker < min(16, len(members)); worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				_, errs[i] = s.Head(ctx, members[i].Identity)
			}
		}()
	}
	for i := range members {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, err := range errs {
		if err != nil {
			return err
		}
	}
	return ctx.Err()
}
